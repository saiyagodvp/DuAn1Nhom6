/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service.impl;

import model.NhanVien;
import repository.NhanVienRepository;
import service.NhanVienSevice;

/**
 *
 * @author ACER
 */
public class NhanVienSeviceImpl implements NhanVienSevice {

    private NhanVienRepository nvrs = new NhanVienRepository();

    @Override
    public NhanVien getOne(String ma) {
        return nvrs.getOne(ma);
    }

}
